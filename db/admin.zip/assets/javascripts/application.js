//= require chartkick
//= require Chart.bundle